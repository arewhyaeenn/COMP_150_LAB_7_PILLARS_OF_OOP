public class PolarPoint implements Point
{
    private double radius;
    private double theta; // theta should be stored in radians, NOT degrees

    PolarPoint(double radius, double theta)
    {
        setRadius(radius);
        setTheta(theta);
    }

    // TODO implement all abstract methods from the Point interface
    // Check the comments in the Point interface for their descriptions!
}
