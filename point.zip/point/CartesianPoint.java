public class CartesianPoint implements Point
{
    private double x;
    private double y;

    CartesianPoint (double x, double y)
    {
        setX(x);
        setY(y);
    }

    // TODO implement all abstract methods from the Point interface
    // Check the comments in the Point interface for their descriptions!
}
