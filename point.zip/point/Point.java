/**
 * Any implementation of the Point interface will have public methods which
 * mutate and access data for a Point with coordinates of type double in the
 * x-y plane.
 *
 * You will write two implementations store data either as cartesian coordinates (x, y)
 * or as polar coordinates (radius, theta).
 *
 * If you're not familiar with cartesian and polar coordinates, watch a one
 * of the video(s) linked from the text.
 *
 * Data should be stored in private variables and should only be
 * accessible through the public methods declared in the interface.
 *
 * Regardless of how the data is stored, methods will need to be defined
 * to find the data in other forms. The implementation which stores
 * data in cartesian form (x, y), it will need methods to calculate, mutate
 * and return the corresponding polar values (radius, theta) and vice-versa.
 *
 * Methods will also need to be defined that allow you to set the data in other forms.
 * For example, a point storing data in cartesian form (x, y) will still need to
 * implement setTheta, which should:
 *      1. Calculate the current radius of the polar form from the stored
 *         x and y values.
 *      2. Use the calculated radius and the input theta value to calculate the
 *         new x and y values.
 *      3. Store the new x and y values.
 */


public interface Point
{
    final static double EQUALITY_THRESHOLD = 0.01; // maximum difference in equality comparisons


    /*
        x, y are the cartesian coordinates of the point.
        radius, theta are the polar coordinates of the point.
        these will be declared in the implementation classes.
     */

/* ACCESSORS */

    /**
     * Move the point so it's locations x value is the input x, and y value remains unchanged.
     * Easy in cartesian, hard in polar.
     *
     * @param x the new x value
     */
    public abstract void setX(double x);

    /**
     * Move the point so its location's y value is the input y, and x value remains unchanged.
     * Easy in cartesian, hard in polar.
     *
     * @param y the new y value
     */
    public abstract void setY(double y);

    /**
     * If setX and setY are already done, this is easy.
     *
     * @param x the new x value
     * @param y the new y value
     */
    public abstract void setCartesianPosition(double x, double y);

    /**
     * Move the point so its location's theta value is the input theta, and the radius value remains unchanged.
     * Easy in polar, hard in cartesian.
     *
     * @param theta given in radians
     */
    public abstract void setTheta(double theta);

    /**
     * Move the point so its location's theta value is the input theta, and the radius value remains unchanged.
     * Easy in polar, hard in cartesian.
     *
     * @param theta given in degrees
     */
    public abstract void setThetaDegrees(double theta);

    /**
     * Move the point so its location's radius value is the input radius, and the theta value remains unchanged.
     * Easy in polar, hard in cartesian.
     *
     * @param radius
     */
    public abstract void setRadius(double radius);

    /**
     * Move the point so its location's radius and theta are that of the input.
     * Easy in polar, harder in cartesian.
     *
     * @param radius
     * @param theta given in radians
     */
    public abstract void setPolarPosition(double radius, double theta);

    /**
     * Move the point so its location's radius and theta are that of the input.
     * Easy in polar, harder in cartesian.
     *
     * @param radius
     * @param theta given in degrees
     */
    public abstract void setPolarPositionDegrees(double radius, double theta);

/* MUTATORS */

    /**
     * @return the Point's x coordinate
     */
    public abstract double getX();

    /**
     * @return the Point's y coordinate
     */
    public abstract double getY();

    /**
     * @return the Point's radius
     */
    public abstract double getRadius();

    /**
     * @return the Point's theta (in radians)
     */
    public abstract double getTheta();

    /**
     * @return the Point's theta in degrees
     */
    public abstract double getThetaDegrees(); // returns the value of theta in degrees.


    /* BUSINESS */

    /**
     * Implementations of the equals method should use the distanceTo method.
     *
     * @param other the Point being compared to `this` for equality.
     * @return true if the distanceTo other is less than the EQUALITY_THRESHOLD, false otherwise.
     */
    public abstract boolean equals(Point other);

    /**
     * The cartesian translate method should move the point in the x and y directions
     * by the values specified in the arguments. That is, (x, y) is a vector in
     * cartesian form, and the point should be translated along that vector.
     * Easy in cartesian, hard in polar...
     *
     * @param x how far to move in the x direction.
     * @param y how far to move in the y direction.
     */
    public abstract void translateCartesian(double x, double y);

    /**
     * The polar translate methods are similar to the cartesian translate, but the input
     * is presented in a different form.
     *
     * @param radius the distance to move.
     * @param theta the angle specifying the direction to move (in radians).
     */
    public abstract void translatePolar(double radius, double theta); // theta is in radians

    /**
     * Same as previous method, but theta is in degrees.
     * @param radius radius the distance to move.
     * @param theta the angle specifying the direction to move (in degrees).
     */
    public abstract void translatePolarDegrees(double radius, double theta); // theta is in degrees

    /**
     * Translate by the other Point (i.e. the vector from the origin to the other Point).
     * I.e. "add" the other point to this one.
     * HINT: this is much easier to do in cartesian, and using the getX/Y and setX/Y methods makes it easy.
     * @param vector the vector (represented as a Point) by which to translate.
     */
    public abstract void translate(Point vector);

    /**
     * Rotate `this` Point by the specified angle about the origin.
     * (I.e. add the input to its theta value; easy in polar, harder in cartesian).
     * HINT: this is much easier to do in polar. Use the getTheta method to get the current theta,
     * add the input to it and use setTheta to rotate :)
     * @param angle the angle by which to rotate (stored in radians)
     */
    public abstract void rotate(double angle); // argument angle is in radians.

    /**
     * The previous method with an extra conversion because degrees -_-
     * @param angle the angle by which to rotate (stored in degrees)
     */
    public abstract void rotateDegrees(double angle); // argument angle is in degrees.

    /**
     * Find the distance from `this` Point to the `other` point.
     * Easy to do in cartesian with the distance formula.
     * @param other the Point to which to find the distance
     * @return the distance to other
     */
    public abstract double distanceTo(Point other);

    /**
     * Create and return a String representing the calling Point.
     * Something like "(cartesian x y)" or "(polar radius theta)".
     * @return dat strang
     */
    public abstract String toString();
}
